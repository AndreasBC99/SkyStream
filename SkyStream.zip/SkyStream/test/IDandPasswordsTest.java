package test;

import java.io.*;

import static org.junit.Assert.assertEquals;
import org.junit.*;

import data.IDandPasswords;

public class IDandPasswordsTest {
    IDandPasswords test;
    int expectedvalue = 0;
    int actualvalue = 0;

    @Before
    public void reset() {
        test = null;
        actualvalue = 0;
        expectedvalue = 0;

    }

    @After
    public void resetagain() {
        test = null;
        expectedvalue = 0;
        actualvalue = 0;
    }

    @Test
    public void userloadingtest() {

        expectedvalue = 4;
        test = new IDandPasswords(
                "/Users/thomasrand/Documents/VS/Projekt_Afslutning/SkyboxEnjoyers-kopi - Kopi 2/SkyStreamUsersFile");

        // ac
        try {
            test.userRecognition();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        assertEquals(test.getLoginInfo().size(), 4);

    }

}