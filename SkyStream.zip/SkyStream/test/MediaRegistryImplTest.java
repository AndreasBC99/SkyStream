package test;

import java.io.*;

import static org.junit.Assert.assertEquals;
import org.junit.*;

import data.IDandPasswords;
import domain.MediaRegistryImpl;

public class MediaRegistryImplTest {
        int expectedvalue;
        int actualvalue;
        MediaRegistryImpl mediaRegistry;

        @Before
        public void reset(){
            mediaRegistry = null;
            actualvalue = 0;
            expectedvalue = 0;
        }

        @After
        public void resetAfter(){
            mediaRegistry = null;
            actualvalue = 0;
            expectedvalue = 0;
        }

        @Test
        public void testSeries(){
            expectedvalue = 100;
            mediaRegistry = new MediaRegistryImpl("/Users/thomasrand/Documents/VS/Projekt_Afslutning/SkyboxEnjoyers-kopi - Kopi 2/film.txt",
             "/Users/thomasrand/Documents/VS/Projekt_Afslutning/SkyboxEnjoyers-kopi - Kopi 2/filmplakater");
             mediaRegistry.initializeData();
             actualvalue = mediaRegistry.getMedias().size();
             assertEquals(expectedvalue, actualvalue);
        }
        
}
