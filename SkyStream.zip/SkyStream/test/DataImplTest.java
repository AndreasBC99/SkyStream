package test;

import java.io.*;
import static org.junit.Assert.assertEquals;
import org.junit.*;
import data.DataImpl;

public class DataImplTest {
    DataImpl tester = new DataImpl("filmplakater");
    int expectedtestvalue = 0;
    int actualtestvalue = 0;

    // resetter før hver test
    @Before
    public void reset() {
        tester = null;
        expectedtestvalue = 0;
        actualtestvalue = 0;

    }

    // resetter efter hver test
    @After
    public void resetagain() {
        tester = null;
        expectedtestvalue = 0;
        actualtestvalue = 0;
    }

    // tester om alle film loader korrekt
    @Test
    public void allmoviesloadingtest() {
        actualtestvalue = 0;
        // arrange
        tester = new DataImpl(
                "/Users/thomasrand/Documents/VS/Projekt_Afslutning/SkyboxEnjoyers-kopi - Kopi 2/film.txt");
        expectedtestvalue = 100;

        // act
        try {
            actualtestvalue = tester.data().size();

            // Assert

        } catch (FileNotFoundException | UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        assertEquals(expectedtestvalue, actualtestvalue);

    }

    // tester om alle serier loader korrekt
    @Test
    public void allseriesloadingtest() {
        // arrange
        tester = new DataImpl(
                "/Users/thomasrand/Documents/VS/Projekt_Afslutning/SkyboxEnjoyers-kopi - Kopi 2/serier.txt");
        expectedtestvalue = 100;

        // act
        try {
            actualtestvalue = tester.data().size();

            // Assert
        } catch (FileNotFoundException | UnsupportedEncodingException e) {
            e.printStackTrace();

        }

        assertEquals(expectedtestvalue, actualtestvalue);

    }

    // tester om alle filmplakater loades korrekt
    @Test
    public void allmoviepicturesloadingtest() {

        expectedtestvalue = 100;

        // act
        tester = new DataImpl(
                "/Users/thomasrand/Documents/VS/Projekt_Afslutning/SkyboxEnjoyers-kopi - Kopi 2/filmplakater");// (System.getProperty("user.dir").concat("/test/filmplakater"));

        actualtestvalue = tester.imageData().size();

        // Assert

        assertEquals(expectedtestvalue, actualtestvalue);

    }

    // tester om alle serieforsider loades korrekt
    @Test
    public void allseriespicturesloadingtest() {

        // arrange
        tester = new DataImpl(
                "/Users/thomasrand/Documents/VS/Projekt_Afslutning/SkyboxEnjoyers-kopi - Kopi 2/serieforsider");
        expectedtestvalue = 100;

        // act
        actualtestvalue = tester.imageData().size();

        // Assert
        assertEquals(expectedtestvalue, actualtestvalue);

    }

}