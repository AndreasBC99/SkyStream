package Exceptions;

import domain.ExceptionFrame;

public class NoMediaClickedException extends Exception{
    public NoMediaClickedException(){
        super("No media chosen");
        ExceptionFrame exceptionFrame = new ExceptionFrame(this.getMessage());

    }
}
