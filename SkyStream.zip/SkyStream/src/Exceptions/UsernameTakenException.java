package Exceptions;

import domain.ExceptionFrame;

public class UsernameTakenException extends Exception {
    public UsernameTakenException(){
        super("User already exists");
    }
}
