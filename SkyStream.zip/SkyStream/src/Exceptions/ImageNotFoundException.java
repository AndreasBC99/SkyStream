package Exceptions;

import domain.ExceptionFrame;

public class ImageNotFoundException extends Exception {
    public ImageNotFoundException(String name){
        super(name);
        ExceptionFrame imageException = new ExceptionFrame("Image not found for media: " + name);
    }
}
