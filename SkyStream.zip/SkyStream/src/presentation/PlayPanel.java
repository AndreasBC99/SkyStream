package presentation;

import java.awt.Dimension;

import java.awt.Color;

import javax.swing.BoxLayout;
import java.awt.BorderLayout;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.LineBorder;

import Exceptions.NoMediaClickedException;
import domain.Media;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

public class PlayPanel extends JPanel implements ActionListener{
    HashMap<String, Integer> seasonsMap;
    private JButton playButton;
    private JButton favoriteButton;
    private JPanel westPanel;
    private JPanel centerPanel;
    private JPanel eastPanel;
    final JComboBox<String> seasonsDropdown;
    final JComboBox<Integer> episodesDropdown;
    private DefaultComboBoxModel<String> seasonsModel;
    private DefaultComboBoxModel<Integer> episodesModel;
    private JTextArea textarea;
    private String[] seasonsArray;
    private String[] episodesArray;
    private final SkyStreamGui skyStreamGui;
    private JLabel seasonText;
    private JLabel episodeText;

    public PlayPanel(SkyStreamGui skyStreamGui){
        super();

        this.skyStreamGui = skyStreamGui;
        this.setVisible(true);
        this.setPreferredSize(new Dimension(0, 100));
        this.setBackground(Color.darkGray);
        textarea = new JTextArea ();
        westPanel = new JPanel();
        eastPanel = new JPanel();
        centerPanel = new JPanel();
        seasonText = new JLabel("Seasons");
        episodeText = new JLabel("Episodes");
        seasonText.setPreferredSize(new Dimension(150, 15));
        episodeText.setPreferredSize(new Dimension(150, 15));
        seasonText.setForeground(Color.white);
        episodeText.setForeground(Color.white);

        westPanel.setBackground(Color.darkGray);
        eastPanel.setBackground(Color.darkGray);
        centerPanel.setBackground(Color.darkGray);

        westPanel.setPreferredSize(new Dimension(250, 100));
        centerPanel.setPreferredSize(new Dimension(150, 100));

        eastPanel.setPreferredSize(new Dimension(150, 100));
        eastPanel.setMinimumSize(new Dimension(150, 100));


        textarea.setBackground(Color.darkGray);
        textarea.setMinimumSize(new Dimension(250, 100));;
        textarea.setColumns(1);
        textarea.setForeground(Color.white);
        textarea.setEditable(false);

        playButton = new JButton("Play");
        playButton.setPreferredSize(new Dimension(150, 50));
        playButton.setVisible(true);
        playButton.addActionListener(this);

        favoriteButton = new JButton();
        favoriteButton.setPreferredSize(new Dimension(150, 50));
        favoriteButton.setVisible(true);

        episodesDropdown = new JComboBox<Integer>();
        seasonsDropdown = new JComboBox<String>();
        seasonsDropdown.setVisible(true);
        episodesDropdown.setVisible(true);
        seasonsDropdown.setPreferredSize(new Dimension(150, 35));
        episodesDropdown.setPreferredSize(new Dimension(150, 35));

        this.setLayout(new BoxLayout(this, BoxLayout.LINE_AXIS)); //Boxlayout ved x aksen
        westPanel.setBorder(new LineBorder(Color.darkGray, 3));
        eastPanel.setBorder(new LineBorder(Color.darkGray, 3));
        centerPanel.setBorder(new LineBorder(Color.darkGray, 3));

        
        eastPanel.setLayout(new BoxLayout(eastPanel, BoxLayout.PAGE_AXIS)); //Boxlayout ved y aksen

        this.add(westPanel);
        this.add(centerPanel);
        this.add(eastPanel);
        westPanel.add(textarea);
        textarea.setAlignmentX(this.LEFT_ALIGNMENT);
        centerPanel.add(playButton);
        eastPanel.add(episodeText);
        eastPanel.add(episodesDropdown);
        eastPanel.add(seasonText);
        eastPanel.add(seasonsDropdown);


    }
    public void seriesClicked(Media media){
        //Er serie trykket på, så skal der oprettes arrays for sæsoner og episoder. 
        episodesModel = new DefaultComboBoxModel<Integer>();
        episodesDropdown.setModel(episodesModel);
        String[] episodesSeasons = media.getSeasons();
        
        seasonsMap = new HashMap<String, Integer>();
        int seasonCounter = 0;
        int episodeCounter = 0;      
        seasonsArray = new String[episodesSeasons.length / 2];
        episodesArray = new String[episodesSeasons.length / 2];

        for(int i = 0; i < episodesSeasons.length; i++){
            if(i%2 == 0){
                seasonsArray[seasonCounter] = episodesSeasons[i];
                seasonCounter++;
            } else {
                episodesArray[episodeCounter] = episodesSeasons[i];
                episodeCounter++;
            }
        }
        for (int i = 0; i < seasonsArray.length; i++){
            seasonsMap.put(seasonsArray[i], Integer.parseInt(episodesArray[i]));
        }
        

        seasonsModel = new DefaultComboBoxModel<>(seasonsArray);
        seasonsDropdown.addActionListener(this);
        seasonsDropdown.setModel(seasonsModel);

        textarea.setText(media.getName() + "\n" + media.getCategory() + "\n" + media.getYear() + "\n" + media.getRating());
        textarea.setVisible(true);
 
    }
    public void movieClicked(Media media){
        //Hvis film er trykket på, lav elementerne i playpanel uden valgmuligheder for episoder og seasons, slet elementer i episoder dropdown menuen
        
        seasonsModel = new DefaultComboBoxModel<>();
        seasonsDropdown.setModel(seasonsModel);
        episodesModel = new DefaultComboBoxModel<Integer>();
        episodesDropdown.setModel(episodesModel);

        textarea.setText(media.getName() + "\n" + media.getCategory() + "\n" + media.getYear() + "\n" + media.getRating());
        textarea.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == seasonsDropdown){
            //Trykkes der på en sæson, skal der genereres det rigtige antal episoder i episode dropdown
            String season = (String) seasonsDropdown.getSelectedItem();
            int episodes = seasonsMap.get(season);//Få integer fra episodesArray ved samme index som værdien af sæsonen
            Integer[] episodesIntArray = new Integer[episodes+1]; //Da defaultcombobox er generisk type kan man ikke bruge int som er primitiv type
            for(int i = 0; i<episodes+1; i++){
                episodesIntArray[i] = i;
            }
            episodesModel = new DefaultComboBoxModel<Integer>(episodesIntArray);

            episodesDropdown.setVisible(true);
            episodesDropdown.setModel(episodesModel);
        }

        if(e.getSource() == playButton){
            if(skyStreamGui.getCurrentMedia() != null){
                JFrame play = new JFrame();
                JButton playFrameButton = new JButton("Play " + skyStreamGui.getCurrentMedia().getName());
                playFrameButton.setVisible(true);
                play.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                play.setExtendedState(JFrame.MAXIMIZED_BOTH); //Full screen
                play.setBackground(Color.black);
                play.setLayout(new BorderLayout());
                play.setVisible(true);
                play.add(playFrameButton, BorderLayout.CENTER);
            }
            else{
                try {
                    throw new NoMediaClickedException();
                } catch (NoMediaClickedException e1) {
                    System.out.println(e1.getMessage());
                }
            }
        }
    }
}
