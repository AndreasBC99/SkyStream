package presentation;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import domain.Media;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class searchFilter extends JFrame {
    private SkyStreamGui skyStreamGui;
    private List<String> mediaNames;

    private JPanel labelPanel;

    private DefaultTableModel model;
    private JTable searchTable;
    private TableRowSorter<TableModel> tableRowSorter;

    private JTextField searchFilter;

    public searchFilter(SkyStreamGui skyStreamGui) {
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setPreferredSize(new Dimension(500, 500));
        this.pack();
        this.setVisible(true);
        this.setTitle("SkyStream");
        this.setResizable(true);
        this.setLocationRelativeTo(null);
        this.skyStreamGui = skyStreamGui;
        model = new DefaultTableModel();
        searchFilter = new JTextField();
        model.addColumn("Name");
        mediaNames = new ArrayList<String>();
        labelPanel = new JPanel();

        for(Media m : skyStreamGui.getMediaList()){//tilføj medier i rows
            
            mediaNames.add(m.getName());
            model.addRow(new Object[] {m.getName()});
        }

        searchTable = new JTable(model, (TableColumnModel) searchTable);
        searchTable.setEnabled(false);
        
        this.add(labelPanel);

        tableRowSorter = new TableRowSorter<>(searchTable.getModel());
        searchTable.setModel(model);
        searchTable.setRowSorter(tableRowSorter);
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JLabel("Type name:"),
                BorderLayout.WEST);
        panel.add(searchFilter, BorderLayout.CENTER);

        labelPanel.setLayout(new BorderLayout());
        labelPanel.add(panel, BorderLayout.SOUTH);
        labelPanel.add(new JScrollPane(searchTable), BorderLayout.CENTER);
        
        searchTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent evt) {
                //Når man klikker på et medie, skal den finde navnet og det tilhørende medie, og kalde mediaclicked
                int row = searchTable.rowAtPoint(evt.getPoint());
                int col = searchTable.columnAtPoint(evt.getPoint());
                for(Media m : skyStreamGui.getMediaList()){
                    if(m.getName() == searchTable.getValueAt(row, col)){
                        skyStreamGui.mediaClicked(m);
                        dispose();
                    }
                }
            }
        });

        searchFilter.getDocument().addDocumentListener(new DocumentListener(){

            @Override
            public void insertUpdate(DocumentEvent de1) {
                //Er der puttet noget i searchfilteret, så filtrer
                String searchWord = searchFilter.getText(); 

                if (searchWord.length() == 0) {
                    tableRowSorter.setRowFilter(null);//Intet skal filtreres
                } else {
                    tableRowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + searchWord)); //Filtrerer efter de bogstaver der skrives
                }
            }

            @Override
            public void removeUpdate(DocumentEvent de2) {
                //er noget slettet i searchfilteret
                String searchWord = searchFilter.getText();

                if (searchWord.length() == 0) {
                    tableRowSorter.setRowFilter(null); 
                } else {
                    tableRowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + searchWord));
                }
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                throw new UnsupportedOperationException("Not supported yet.");
            }

        });

    }

}

