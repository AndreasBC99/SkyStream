package presentation;

import java.io.IOException;
import java.util.*;
import java.awt.*;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneLayout;
import javax.swing.border.LineBorder;

import domain.Media;

public class mediaPanel extends JPanel{

    GridBagConstraints gbc; //Gridbaglayoutet
    JScrollPane pane;
    private final SkyStreamGui skyStreamGui;
    private ArrayList<Media> mediaList;
    String category = "All";
    String type = "All";

    public mediaPanel(SkyStreamGui skyStreamGui) throws IOException {
        super();
        this.skyStreamGui = skyStreamGui;
        this.setVisible(true);
        this.setLayout(new GridBagLayout());
        this.setBackground(Color.gray);
        this.setBorder(new LineBorder(Color.gray, 3));
        
        gbc =  new GridBagConstraints();
        mediaList = skyStreamGui.getMediaList();

        //Tilføj alle medier med gridbaglayout
        gbc.gridx = 0;
        gbc.gridy = 0;
        for(Media m : mediaList){
            makeButton(m);
            gbc.gridx += 1;
            if (gbc.gridx % 4 == 0) {
                gbc.gridy += 1;
                gbc.gridx = 0;
            }

        }

    }

    public JScrollPane makeScrollPane(){
        //Tilføj scroll funktionalitet til panelet
        pane = new JScrollPane(this);
        pane.setLayout(new ScrollPaneLayout());
        pane.getVerticalScrollBar().setUnitIncrement(16);

        return pane;
    }

    public void makeButton(Media media){
        //Lav knap tilhørende medie
        ImageIcon imageIcon = new ImageIcon(media.getImage());

        JButton mediaButton = new JButton();
        mediaButton.setFocusable(false);
        mediaButton.setIcon(imageIcon);
        mediaButton.addActionListener(e -> skyStreamGui.mediaClicked(media));
        this.add(mediaButton, gbc);
        mediaButton.setVisible(true);
    }


    public void changeCategory(String category){
        //Vis film fra en anden kategori
        this.category = category;
        this.removeAll();
        gbc.gridx=0;
        gbc.gridy=0;

            for(Media m : mediaList){
                if(m.getCategory().contains(category) && m.getType().contains(type)){
                        
                    makeButton(m);
                    gbc.gridx +=1;
                    if (gbc.gridx % 4 == 0) {
                        gbc.gridy += 1;
                        gbc.gridx = 0;
                    }
                }
    
            }
        
        this.updateUI();

    }
    public void changeType(String type){
        //Vis film af en anden type
        this.type = type;
        this.removeAll();
        gbc.gridx=0;
        gbc.gridy=0;

            for(Media m : mediaList){
                if(m.getCategory().contains(category) && m.getType().contains(type)){
                        
                    makeButton(m);
                    gbc.gridx +=1;
                    if (gbc.gridx % 4 == 0) {
                        gbc.gridy += 1;
                        gbc.gridx = 0;
                    }
                }
    
            }
        
        this.updateUI();

    }

    public void showFavourites(){
        //Vis film fra favoritlisten
        this.removeAll();
        gbc.gridx=0;
        gbc.gridy=0;

        for(Media m : skyStreamGui.getFavourites()){
                makeButton(m);
                gbc.gridx +=1;
                if (gbc.gridx % 4 == 0) {
                    gbc.gridy += 1;
                    gbc.gridx = 0;
                }
            }
            this.updateUI();
        }
}

