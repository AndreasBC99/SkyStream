package presentation;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import Exceptions.UsernameTakenException;
import domain.UserImpl;

import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;


//ActionListener skal importeres, så en metode kan være handlingsbaseret
public class LoginPage implements ActionListener{
    JFrame frame = new JFrame();
    
    private JButton loginButton = new JButton("Login");
    private JButton resetButton = new JButton("Reset");
    private JButton newUserButton = new JButton("New user");

    public JTextField userIDField = new JTextField();
    public JPasswordField userPasswordField = new JPasswordField();

    private JLabel userIDLabel = new JLabel("UserID:");
    private JLabel userPasswordLabel = new JLabel("Password:");
    private JLabel messageLabel = new JLabel();
    private UserImpl userImpl;

    HashMap<String, String> loginInfo = new HashMap<String, String>();
    
    public LoginPage() {
 
        userImpl = new UserImpl("lib/mediaData/SkyStreamUsersFile");
        loginInfo = userImpl.getLoginInfo();
        frame.setResizable(false);
        userIDLabel.setBounds(50, 100, 75, 25);
        userPasswordLabel.setBounds(50, 150, 75, 25);
        
        messageLabel.setBounds(150, 300, 250, 35);
        messageLabel.setFont(new Font(null, Font.ITALIC, 25));
        
        userIDField.setBounds(125, 100, 200, 25);
        userPasswordField.setBounds(125, 150, 200, 25);

        loginButton.setBounds(125, 200, 100, 25);
        loginButton.setFocusable(false);
        loginButton.addActionListener(this);

        resetButton.setBounds(225, 200, 100, 25);
        resetButton.setFocusable(false);
        resetButton.addActionListener(this);

        newUserButton.setBounds(175, 250, 100, 25);
        newUserButton.setFocusable(false);
        newUserButton.addActionListener(this);

        frame.add(userIDLabel);
        frame.add(userPasswordLabel);
        frame.add(messageLabel);
        frame.add(userIDField);
        frame.add(userPasswordField);
        frame.add(loginButton);
        frame.add(resetButton);
        frame.add(newUserButton);

        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420, 420);
        frame.setLayout(null);
        frame.setVisible(true);

} 

    @Override
    public void actionPerformed(ActionEvent e) {
        //Sletter alt på JTextField
        if (e.getSource() == resetButton) {
            userIDField.setText("");
            userPasswordField.setText("");
        }
        //Bemærk forskellen mellem initialiseringen af userID og password
        if (e.getSource() == loginButton) {
            String userID = userIDField.getText();
            String password = String.valueOf(userPasswordField.getPassword()); //Konverterer password til fra char til string og initialiseres til "password"

            userImpl.userRecognition();
            loginInfo = userImpl.getLoginInfo();
            if (loginInfo.containsKey(userID)) {
                messageLabel.setText("");
                //Brugeren eksisterer
                if (loginInfo.get(userID).equals(password)) {
                    messageLabel.setForeground(Color.GREEN);
                    messageLabel.setText("Login succesfull");
                    try {
                        SkyStreamGui Gui = new SkyStreamGui();
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                    frame.setVisible(false);

                }
            } else {
                //Brugeren eksisterer ikke
                messageLabel.setForeground(Color.RED);
                messageLabel.setText("Incorrect");
            }

        }
        //Oprettelse af bruger
        if(e.getSource() == newUserButton) {
            userImpl.userRecognition();
            loginInfo = userImpl.getLoginInfo();

            if(loginInfo.containsKey(userIDField.getText())){
                try {
                    throw new UsernameTakenException();
                } catch (UsernameTakenException e1) {
                    e1.printStackTrace();
                    messageLabel.setText("User already exists");
                    messageLabel.setForeground(Color.RED);

                }
            }
            else if (!"".equals(userIDField.getText()) && !"".equals(String.valueOf(userPasswordField.getPassword()))) {
                    userImpl.userSaveFile(userIDField.getText(), String.valueOf(userPasswordField.getPassword()));
                    messageLabel.setForeground(Color.GREEN);
                    messageLabel.setText("User created");
               

            } else {
                messageLabel.setForeground(Color.RED);
                messageLabel.setText("Not finished");

            }

        }
    }
}
