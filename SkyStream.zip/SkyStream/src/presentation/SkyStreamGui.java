package presentation;
import java.awt.*;
import javax.swing.*;

import domain.Media;
import domain.MediaRegistryImpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;

public class SkyStreamGui extends JFrame{
    private int SCREEN_HEIGHT = 1000;
    private int SCREEN_WIDTH = 750;

    private Media currentMedia;
    private ArrayList<Media> mediaList;

    private Container container;
    private BorderLayout layout;
    private mediaPanel mediaPanel;
    private navPanel navPanel;
    private PlayPanel playPanel;

    public SkyStreamGui() throws IOException{ //Skab GUI
        currentMedia = null;
        MediaRegistryImpl movies = new MediaRegistryImpl("lib/mediaData/film.txt", "lib/mediaData/filmplakater");
        MediaRegistryImpl series = new MediaRegistryImpl("lib/mediaData/serier.txt", "lib/mediaData/serieforsider");
        movies.initializeData();
        series.initializeData();
        mediaList = new ArrayList<Media>();
        mediaList.addAll(movies.getMedias());
        mediaList.addAll(series.getMedias());

        mediaPanel = new mediaPanel(this);
        navPanel = new navPanel(this);
        playPanel = new PlayPanel(this);

        Collections.sort(mediaList, new Comparator<Media>() {
            //Sorter listen med medier efter alfabet
            public int compare(Media m1, Media m2){
                return m1.getName().compareTo(m2.getName()); 
            }
        });
        
        
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setPreferredSize(new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT));
        this.pack();
        this.setVisible(true);
        this.setTitle("SkyStream");
        this.setResizable(true);
        this.setLocationRelativeTo(null);

        container = this.getContentPane();
        container.setBackground(Color.black);
        layout = new BorderLayout();
        container.setLayout(layout);
        container.setSize(1000, 100);
        container.add(playPanel, BorderLayout.SOUTH);
        container.add(mediaPanel.makeScrollPane(), BorderLayout.CENTER);
        container.add(navPanel, BorderLayout.NORTH);
        
        
        this.pack();
    }

    public void showFavourites(){
        //Vis favorit siden
        mediaPanel.showFavourites();
    }
    public ArrayList<Media> getMediaList(){
        //Hent alle medier
        return mediaList;
    }
    public LinkedHashSet<String> getAllCategories(){
        //Få alle de kategorier der findes i LinkedHashSet så de er sorteret efter tilføjelsestidspunkt og ingen duplikater
        LinkedHashSet<String> allCategories = new LinkedHashSet<String>();
        allCategories.add("All");
        for(Media m : mediaList){
            allCategories.addAll(m.getCategory());
        }
        return allCategories;
    }

    public void changeCategory(String category){
        //Skift visningen af film ud fra category
        mediaPanel.changeCategory(category);
    }

    public void changeType(String type){
        //Skift visningen af film ud fra type
        mediaPanel.changeType(type);
    }
   
    public void mediaClicked(Media media){
        // Er et medietrykket på, skift favourit til unfavourit hvis den er i favouritlisten, display tekst om filmen
        currentMedia = media;
        if(navPanel.getFavourites().contains(media)){
            navPanel.isFavourite(true);
        } else{
            navPanel.isFavourite(false);
        }
        if(media.getType().contains("Series")){
            playPanel.seriesClicked(media);
        } else if(media.getType().contains("Movie")){
            playPanel.movieClicked(media);
        }
    }

    public Media getCurrentMedia(){
        return currentMedia;
    }

    public ArrayList<Media> getFavourites(){
        return navPanel.getFavourites();
    }

    public static void main(String[] args) {

        LoginPage loginPage = new LoginPage();
    }

}
