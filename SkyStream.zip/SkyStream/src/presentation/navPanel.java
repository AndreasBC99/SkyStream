package presentation;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.awt.event.ActionEvent;

import javax.swing.*;
import javax.swing.JComboBox;
import javax.swing.JPanel;

import Exceptions.NoMediaClickedException;
import domain.Media;

import java.awt.Color;

public class navPanel extends JPanel implements ActionListener{

    private JButton seriesButton;
    private JButton movieButton;
    private JButton allButton;
    private JButton favouriteButton;
    private JButton showFavouritesButton;
    private JButton openSearch;
    private final SkyStreamGui skyStreamGui;
    private String category = "All";
    private String type = "All";
    private final JComboBox<String> dropdown;
    private ArrayList<Media> favouriteList;

    public navPanel(SkyStreamGui skyStreamGui){
        super();
        this.skyStreamGui = skyStreamGui;
        this.setVisible(true);
        this.setBackground(Color.darkGray);

        FlowLayout layout = new FlowLayout(FlowLayout.LEADING, 0, 30);
        this.setLayout(layout);

        favouriteList = new ArrayList<Media>();
        //Hent alle kategorier til at generere en dropdown til visning af kategorier
        LinkedHashSet<String> categories = skyStreamGui.getAllCategories();
        dropdown = new JComboBox<String>(categories.toArray(new String[categories.size()]));
        dropdown.addActionListener(this);
        this.add(dropdown);

        showFavouritesButton = new JButton("Show Favourites");
        favouriteButton = new JButton("Favourite");
        seriesButton = new JButton("Series");
        movieButton = new JButton("Movies");
        allButton = new JButton("All");
        openSearch = new JButton("Search");
        seriesButton.addActionListener(this);
        movieButton.addActionListener(this);
        allButton.addActionListener(this);
        favouriteButton.addActionListener(this);
        showFavouritesButton.addActionListener(this);
        openSearch.addActionListener(this);

        this.add(allButton);
        this.add(seriesButton);
        this.add(movieButton);
        this.add(favouriteButton);
        this.add(showFavouritesButton);
        this.add(openSearch);
    }

    public ArrayList<Media> getFavourites(){
        return favouriteList;
    }

    public void isFavourite(Boolean b){
        //Kontroller favoritknappen tekst udfra om mediet er favorit
        if(b){
            favouriteButton.setText("Unfavourite");
        } else{
            favouriteButton.setText("Favourite");
        }
    }

    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == dropdown){
            category = (String) dropdown.getSelectedItem();
            if(category == "All"){
                skyStreamGui.changeCategory(category);    

            }else{
                skyStreamGui.changeCategory(category);    
            }
        }
        if(e.getSource() == allButton){
            type = "All";
            skyStreamGui.changeType(type);
        }
        
        if(e.getSource() == movieButton){
            type = "Movie";
            skyStreamGui.changeType(type);
        }

        if(e.getSource() == seriesButton){
            type = "Series";
            skyStreamGui.changeType(type);
        }

        if(e.getSource() == seriesButton){
            type = "Series";
            skyStreamGui.changeType(type);
        }

        if(e.getSource() == showFavouritesButton){
            skyStreamGui.showFavourites();
        }
        if(e.getSource() == openSearch){
            searchFilter search = new searchFilter(skyStreamGui);
        }

        if(e.getSource() == favouriteButton){
            //Ændre på teksten i favoritknappen og tilføj/slet fra favoritliste
            if(skyStreamGui.getCurrentMedia() == null){
                try {
                    throw new NoMediaClickedException();
                } catch (NoMediaClickedException e1) {
                    System.out.println(e1.getMessage());
                }
            } else if(favouriteList.contains(skyStreamGui.getCurrentMedia())) {
                favouriteButton.setText("Favourite");
                favouriteList.remove(skyStreamGui.getCurrentMedia());
            } else{
                favouriteButton.setText("Unfavourite");
                favouriteList.add(skyStreamGui.getCurrentMedia());
            }
            
        }
    }

}
