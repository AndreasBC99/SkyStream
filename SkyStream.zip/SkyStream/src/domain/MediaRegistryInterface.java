package domain;

import java.util.ArrayList;

public interface MediaRegistryInterface {
    

    public void initializeData();
    
    public ArrayList<Media> getMedias();

}
