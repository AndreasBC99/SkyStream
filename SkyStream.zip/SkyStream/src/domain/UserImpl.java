package domain;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

import data.IDandPasswords;


public class UserImpl {
    IDandPasswords idandPasswords;
    HashMap<String, String> loginInfo;
    public UserImpl(String path){
        
        idandPasswords = new IDandPasswords(path);
        loginInfo = idandPasswords.getLoginInfo();

        //LoginPage loginPage = new LoginPage(idandPasswords.getLoginInfo());
    }
    public HashMap<String, String> getLoginInfo(){
        return loginInfo;
    }
    public void userRecognition(){
        try {
            idandPasswords.userRecognition();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    public void userSaveFile(String userID, String userPass){
        try {
            idandPasswords.userSaveFile(userID, userPass);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
        
}
