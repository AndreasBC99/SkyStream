package domain;

import java.awt.Dimension;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;

public class ExceptionFrame extends JFrame {
    public ExceptionFrame(String text){
        this.setPreferredSize(new Dimension(200, 200));
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        JTextArea errorText = new JTextArea(text);
        JButton close = new JButton("Close");
        errorText.setEditable(false);
        close.addActionListener(e -> dispose());
        this.setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));
        this.pack();
        this.setLocationRelativeTo(null);

        this.getContentPane().add(errorText);
        this.getContentPane().add(close);
        this.setVisible(true);

    }
}
