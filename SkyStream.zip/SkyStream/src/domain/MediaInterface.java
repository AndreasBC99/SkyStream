package domain;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public interface MediaInterface {

    public void display();

    public String getName();

    public String getYear();

    public ArrayList<String> getCategory();

    public String getRating();

    public BufferedImage getImage();


}

