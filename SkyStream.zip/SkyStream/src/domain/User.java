package domain;

import java.util.HashSet;

public class User {
    protected String username;
    protected String password;
    protected int age;
    protected HashSet<Media> favouriteList;

    User(String username, String password, int age) {
        this.username = username;
        this.password = password;
        this.age = age; //Ikke implementeret
        favouriteList = new HashSet<Media>(); //Ikke implementeret

    }

    public String getName() {
        return username;
       }
    public String getPassword() {
        return password;
    }
}