package domain;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public abstract class Media implements MediaInterface{
    protected String name;
    protected String year;
    protected String category;
    protected String rating;
    protected String type;
    protected BufferedImage mediaImage;
    protected ArrayList<String> categories;


    Media(String name, String year, String category, String rating, String type, BufferedImage mediaImage) {
        this.name = name;
        this.year = year;
        this.category = category;  
        this.rating = rating;
        this.type = type;
        this.mediaImage = mediaImage;
    }
    public ArrayList<String> getType(){
        ArrayList<String> types = new ArrayList<String>();
        types.add(type);
        types.add("All");
        return types;
    }
    public void display(){

    }
    public String getName() {
        return name;
    }

    public String getYear() {
        return year;
    }
    public ArrayList<String> getCategory() {
        categories = new ArrayList<String>();
        categories.add("All");
        categories.addAll(Arrays.asList(category.split("\\s*,\\s*")));
        return categories;
    }

    public String getRating() {
        return rating;
    }

    public BufferedImage getImage() {
        return mediaImage;
    
    }
    
    public String[] getSeasons() {
        return null;
    }

    public HashMap<String, Integer> getMap(){
        return null;
    }
}

