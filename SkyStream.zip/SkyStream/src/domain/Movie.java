package domain;
import java.awt.image.BufferedImage;
public class Movie extends Media {

    Movie (String name, String year, String category, String rating, String type, BufferedImage image) {
        super(name, year, category, rating, type, image);
    }

    @Override
    public void display(){
        System.out.println(name + " " + year + " " + category + " " + rating);
    }
}