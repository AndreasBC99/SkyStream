package domain;

import java.awt.image.BufferedImage;

public class Series extends Media{
   protected String seasons;
    Series(String name, String year, String category, String rating, String seasons, String type, BufferedImage image){
        super(name, year, category, rating, type, image);
        this.seasons = seasons;
    }

    @Override
    public void display(){
        System.out.println(name + " " + year + " " + category + " " + rating + " " + seasons);
    }
    @Override
    public String[] getSeasons(){
        String[] seasonArray = seasons.split("\\W\\s*"); //split , og -
        return seasonArray;
    }
}
