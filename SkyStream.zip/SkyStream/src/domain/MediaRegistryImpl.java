package domain;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

import Exceptions.ImageNotFoundException;

import java.util.ArrayList;
import java.awt.image.BufferedImage;
import data.DataImpl;


public class MediaRegistryImpl implements MediaRegistryInterface {
    private DataImpl dI;
    private DataImpl imagedI;
    private Map<String, BufferedImage> imageMap;

    private String textpath;
    private String imagePath;
    ArrayList<Media> medias = new ArrayList<>();


    public MediaRegistryImpl(String textpath, String imagePath) {
        dI = new DataImpl(textpath);
        imagedI = new DataImpl(imagePath);
        this.textpath = textpath;
        this.imagePath = imagePath;
    }
    public void initializeData() {
        //Inddel data i objekter af medier
        try {
            List<String> mediaString = dI.data();
            imageMap = imagedI.imageData();

            for (String m : mediaString) {
                String[] line = m.split("\\s*;\\s*"); //Fjerner mellemrum før og efter semikolon
                String name = line[0];
                String year = line[1];
                String category = line[2];
                String rating = line[3];
                if(textpath.equals("lib/mediaData/film.txt") || //For testing
                textpath.equals("/Users/thomasrand/Documents/VS/Projekt_Afslutning/SkyboxEnjoyers-kopi - Kopi 2/film.txt")){
                    if(!imageMap.containsKey(name)){
                        throw new ImageNotFoundException(name);
                    }
                    Movie movie = new Movie(name, year, category, rating, "Movie", imageMap.get(name));
                    medias.add(movie);
                } else {
                    String seasons = line[4];
                    Series series = new Series(name, year, category, rating, seasons, "Series", imageMap.get(name));
                    medias.add(series);
                
                }
        }
    }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch(UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ImageNotFoundException e) {
            e.printStackTrace();
        }
        
    

    }
    public ArrayList<Media> getMedias(){
        return medias;
    }

}

