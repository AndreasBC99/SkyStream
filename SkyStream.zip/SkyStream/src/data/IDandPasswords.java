package data;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

public class IDandPasswords {
  HashMap<String, String> logininfo = new HashMap<String, String>();
  public Object getLoginInfo;
  HashMap<String, String> updatedLoginInfo = new HashMap<String, String>();
  String path;
  File userIDFile;

  public IDandPasswords(String path) {
    this.path = path;
    userIDFile = new File(path);
  }

  public HashMap<String, String> getLoginInfo() {
    return logininfo;

  }

  // BRUGES TIL GENKENDELSE AF EKSISTERENDE BRUGERE
  public void userRecognition() throws FileNotFoundException {
    try (BufferedReader br = new BufferedReader(new FileReader(userIDFile))) {
      Object[] Lines = br.lines().toArray();

      for (int i = 0; i < Lines.length; i++) {
        String Line = Lines[i].toString().trim();
        String[] Row = Line.split(",");
        logininfo.put(Row[0], Row[1]);

      }
    } catch (FileNotFoundException e) {
      throw e;
    } catch (IOException e) {
      e.printStackTrace();
    }

  }

  // BRUGES TIL OPRETTELSE AF BRUGER
  public void userSaveFile(String userID, String userPass) throws IOException {
    if (!userIDFile.exists()) { // En ny fil bliver skabt såfremt den ikke eksisterer i forvejen
      userIDFile.createNewFile();
    }
    // Nedenstående tilføjer til txt-filen
    FileWriter fw = new FileWriter(userIDFile, true);
    BufferedWriter bw = new BufferedWriter(fw);
    PrintWriter pw = new PrintWriter(bw);
    pw.println(userID + "," + userPass);

    pw.flush();
    pw.close();
    bw.close();

  }
}
