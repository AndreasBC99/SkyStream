package data;
import java.io.*;
import java.util.*;
import java.util.HashMap;

import javax.imageio.ImageIO;

import java.awt.image.BufferedImage;

public class DataImpl {
    String path;
    ArrayList<String> media = new ArrayList<>();
    public List<String> load;

   HashMap<String, BufferedImage> mediaImage;
   String imageName;

    public DataImpl(String path) {
        this.path = path;


    }

    public List<String> data() throws FileNotFoundException, UnsupportedEncodingException {
        
        File file = new File(path);
        //BufferedReader brugt i stedet for scanner
        BufferedReader s = new BufferedReader(new InputStreamReader(new FileInputStream(file.getAbsolutePath()), "ISO-8859-1"));

        String line;
        try {  //Buffered reader kaster IOexception(Input/output fejl)
            while ((line = s.readLine()) != null) {
                media.add(line);
            } 
        } catch (IOException e) {
            e.printStackTrace();
        }
        try { 
            s.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return media;
    }
    public void display() {

        System.out.println(media);

    }
    

    public HashMap<String, BufferedImage> imageData() {
        File file = new File(path);
        File[] allImageFiles = file.listFiles();
        
        mediaImage = new HashMap<>();

        for(int i = 0; i < allImageFiles.length; i ++) {
            try {
                mediaImage.put(allImageFiles[i].getName().replace(".jpg", "").replace("„", "ä"), ImageIO.read((allImageFiles[i])));

            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
         
        }
        return mediaImage;

    }



}


