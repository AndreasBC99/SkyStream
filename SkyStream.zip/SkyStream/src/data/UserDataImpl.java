package data;
import java.util.HashSet;
import domain.User;

public class UserDataImpl {
    protected HashSet<User> userList;
    
    
}
